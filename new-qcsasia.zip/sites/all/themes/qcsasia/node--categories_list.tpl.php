<div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>
    <h2><?= $title ?></h2><?php
    displayCategories(); ?>
</div>