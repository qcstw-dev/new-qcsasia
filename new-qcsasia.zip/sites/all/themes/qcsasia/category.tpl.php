<h2>Category: <?= $term_name ?></h2><?php
displayProducts($term); ?>